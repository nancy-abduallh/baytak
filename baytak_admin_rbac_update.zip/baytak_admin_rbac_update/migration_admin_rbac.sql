-- =====================================================================
--  BAYTAK — migration: admin roles & granular permissions
--  Run AFTER schema.sql + seed.sql have already been applied.
--  Safe to re-run (guards included), MySQL 8.x.
-- =====================================================================
USE baytak_db;

-- 1) Widen the role enum to include 'operations' (already expected by the
--    admin dashboard UI) alongside the existing roles.
ALTER TABLE admins
  MODIFY COLUMN role ENUM('super_admin','operations','support','finance')
    NOT NULL DEFAULT 'support';

-- 2) Add the granular permissions column. `super_admin` accounts ignore
--    this column entirely (they get every permission in application
--    code); every other admin is limited to exactly what's listed here.
--    Valid keys: dashboard.view, orders.view, orders.update_status,
--    orders.delete, technicians.manage, users.manage, categories.manage,
--    admins.manage.
ALTER TABLE admins
  ADD COLUMN IF NOT EXISTS permissions JSON NOT NULL DEFAULT (JSON_ARRAY())
    AFTER role;

-- 3) Track updates (create_admin/update_admin now change this row).
ALTER TABLE admins
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP NOT NULL
    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER is_active;

-- 4) Backfill: give the existing seeded super_admin an explicit (though
--    unused by app logic) full permission set, just so the column never
--    reads as empty/misleading in phpMyAdmin.
UPDATE admins
SET permissions = JSON_ARRAY(
  'dashboard.view','orders.view','orders.update_status','orders.delete',
  'technicians.manage','users.manage','categories.manage','admins.manage'
)
WHERE role = 'super_admin';
