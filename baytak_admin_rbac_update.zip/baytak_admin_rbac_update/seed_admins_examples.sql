-- =====================================================================
--  BAYTAK — optional sample data for the new admin roles/permissions
--  Run AFTER schema.sql + seed.sql + migration_admin_rbac.sql
--  Passwords below are placeholders — replace with real bcrypt hashes
--  (or just create these through the "إضافة مشرف" screen instead, which
--  hashes the password correctly server-side).
-- =====================================================================
USE baytak_db;
SET NAMES utf8mb4;

INSERT INTO admins (full_name, email, password_hash, role, permissions, is_active) VALUES
('نورة العتيبي', 'noura.ops@baytak.sa', '$2b$12$replaceWithRealBcryptHash', 'operations',
  JSON_ARRAY('dashboard.view','orders.view','orders.update_status','technicians.manage','categories.manage'), 1),
('فهد الغامدي', 'fahad.support@baytak.sa', '$2b$12$replaceWithRealBcryptHash', 'support',
  JSON_ARRAY('dashboard.view','orders.view','orders.update_status','users.manage'), 1),
('ريم القحطاني', 'reem.finance@baytak.sa', '$2b$12$replaceWithRealBcryptHash', 'finance',
  JSON_ARRAY('dashboard.view','orders.view'), 1);
